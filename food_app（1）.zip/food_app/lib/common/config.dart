import 'package:flutter/material.dart';

///配置

///首页标题背景色
const homeTitleColor = Color(0xffF8F8F8);

const String baseUrl = "http://www.themealdb.com/api/json/v1/1/";
