///常量

const String smilingFace = "😊";
const String cryingFace = "😭";
const double padding = 10;
const List<String> sortString = ["Sort By", "Newest", "Popularity"];
